import tensorflow as tf


#############################################################
def batch_norm_wrapper(inputs, phase_train=None, decay=0.99):
  epsilon = 2e-4
  out_dim = inputs.get_shape()[-1]
  scale = tf.Variable(tf.ones([out_dim]))
  beta = tf.Variable(tf.zeros([out_dim]))
  pop_mean = tf.Variable(tf.zeros([out_dim]), trainable=False)
  pop_var = tf.Variable(tf.ones([out_dim]), trainable=False)

  if phase_train == None:
    return tf.nn.batch_normalization(inputs, pop_mean, pop_var, beta, scale, epsilon)

  rank = len(inputs.get_shape())
  axes = range(rank - 1)  # nn:[0], conv:[0,1,2]
  batch_mean, batch_var = tf.nn.moments(inputs, axes)

  ema = tf.train.ExponentialMovingAverage(decay=decay)

  def update():  # Update ema.
    ema_apply_op = ema.apply([batch_mean, batch_var])
    with tf.control_dependencies([ema_apply_op]):
      return tf.nn.batch_normalization(inputs, tf.identity(batch_mean), tf.identity(batch_var), beta, scale, epsilon)
  def average():  # Use avarage of ema.
    train_mean = pop_mean.assign(ema.average(batch_mean))
    train_var = pop_var.assign(ema.average(batch_var))
    with tf.control_dependencies([train_mean, train_var]):
      return tf.nn.batch_normalization(inputs, train_mean, train_var, beta, scale, epsilon)

  return tf.cond(phase_train, update, average)
#############################################################


############parametric reluの関数##################
def prelu(_x,name):
  alphas = tf.get_variable(name,
                           _x.get_shape()[-1],
                           initializer=tf.constant_initializer(0.3),
                           dtype=tf.float32)
  pos = tf.nn.relu(_x)
  neg = alphas * (_x - abs(_x)) * 0.5
  return pos + neg
###################################################

############Random leaky relu######################
def rrelu(_x,step):
    alphas = tf.cond(tf.equal(step,1),lambda: tf.random_uniform(_x.get_shape()[-1],0.1,0.5,dtaype=tf.float32),lambda:tf.constant(0.3,_x.get_shape()[-1],dtype=tf.float32))
    pos = tf.nn.relu(_x)
    neg = alphas * (_x - abs(_x)) * 0.5
    return pos + neg
####################################################

###################################################
def Conv(images, FilterSize, OutNumChannel, key):
    img_shape = images.get_shape()
    numofchannel = int(img_shape[4])
    b_Conv = tf.get_variable(name='BConv' + key,initializer=(tf.truncated_normal(shape=[OutNumChannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    w_Conv = tf.get_variable(name='WConv' + key, initializer=(tf.truncated_normal([FilterSize, FilterSize, FilterSize, numofchannel, OutNumChannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    ConvMap = tf.nn.conv3d(images, w_Conv, strides=[1, 1, 1, 1, 1], padding='SAME')
    Conv_cutoff = prelu(ConvMap + b_Conv, 'ConvPrelu1' + key)
    return Conv_cutoff
#################################################

###################################################
def ConvOnly(images, FilterSize, OutNumChannel, key):
    img_shape = images.get_shape()
    numofchannel = int(img_shape[4])
    w_Conv = tf.get_variable(name='WConv' + key, initializer=(tf.truncated_normal([FilterSize, FilterSize, FilterSize, numofchannel, OutNumChannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    ConvMap = tf.nn.conv3d(images, w_Conv, strides=[1, 1, 1, 1, 1], padding='SAME')
    return ConvMap
#################################################

#################################################
def PoolConv(images, FilterSize, OutNumChannel, key):
    img_shape = images.get_shape()
    numofchannel = int(img_shape[4])
    b_PoolConv = tf.get_variable(name='BPoolConv' + key,initializer=(tf.truncated_normal(shape=[OutNumChannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    w_PoolConv = tf.get_variable(name='WPoolConv' + key, initializer=(tf.truncated_normal([FilterSize, FilterSize, FilterSize, numofchannel, OutNumChannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    PoolConvMap = tf.nn.conv3d(images, w_PoolConv, strides=[1, 2, 2, 2, 1], padding='SAME')
    PoolConv_cutoff = prelu(PoolConvMap + b_PoolConv, 'PoolConvPrelu' + key)
    return PoolConv_cutoff
#################################################

#################################################
def DeConv(images, FilterSize, OutNumChannel, key):
    img_shape = images.get_shape()
    BatchSize = int(img_shape[0])
    depth = int(img_shape[1])
    height = int(img_shape[2])
    width = int(img_shape[3])
    numofchannel = int(img_shape[4])
    ##deconvにより特徴マップを元の大きさに戻していく
    b_DeConv = tf.get_variable(name='BDeConv' + key,initializer=(tf.truncated_normal(shape=[OutNumChannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    w_DeConv = tf.get_variable(name='WDeConv' + key, initializer=(tf.truncated_normal([FilterSize, FilterSize, FilterSize, OutNumChannel, numofchannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    DeConvMap = tf.nn.conv3d_transpose(images, w_DeConv,[BatchSize, int(depth * 2), int(height * 2), int(width * 2), OutNumChannel],[1, 2, 2, 2, 1], padding='SAME')
    DeConv_cutoff = prelu(DeConvMap + b_DeConv, 'DeConvPrelu' + key)
    return DeConv_cutoff
###############################################

#################################################
def DeConv(images, FilterSize, OutNumChannel, key):
    img_shape = images.get_shape()
    BatchSize = int(img_shape[0])
    depth = int(img_shape[1])
    height = int(img_shape[2])
    width = int(img_shape[3])
    numofchannel = int(img_shape[4])
    ##deconvにより特徴マップを元の大きさに戻していく
    b_DeConv = tf.get_variable(name='BDeConv' + key,initializer=(tf.truncated_normal(shape=[OutNumChannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    w_DeConv = tf.get_variable(name='WDeConv' + key, initializer=(tf.truncated_normal([FilterSize, FilterSize, FilterSize, OutNumChannel, numofchannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    DeConvMap = tf.nn.conv3d_transpose(images, w_DeConv,[BatchSize, int(depth * 2), int(height * 2), int(width * 2), OutNumChannel],[1, 2, 2, 2, 1], padding='SAME')
    DeConv_cutoff = prelu(DeConvMap + b_DeConv, 'DeConvPrelu' + key)
    return DeConv_cutoff
###############################################

#################Global Convolutional Network##################################
def GCN3D(images,FilterSize,OutNumChannel,key):
    img_shape = images.get_shape()
    numofchannel = int(img_shape[4])
    num_channel1 = OutNumChannel

    w_depth_conv1 = tf.get_variable(name='WGCN3DDepthConv1' + key, initializer=(tf.truncated_normal([FilterSize, 1, 1, numofchannel, num_channel1], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    depth_conv1 = tf.nn.conv3d(images, w_depth_conv1, strides=[1, 1, 1, 1, 1], padding='SAME')
    w_depth_conv2 = tf.get_variable(name='WGCN3DDepthConv2' + key, initializer=(tf.truncated_normal([1, FilterSize, 1, num_channel1, num_channel1], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    depth_conv2 = tf.nn.conv3d( depth_conv1, w_depth_conv2, strides=[1, 1, 1, 1, 1], padding='SAME')
    w_depth_conv3 = tf.get_variable(name='WGCN3DDepthConv3' + key, initializer=(tf.truncated_normal([1, 1, FilterSize, num_channel1, num_channel1], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    depth_conv3 = tf.nn.conv3d( depth_conv2, w_depth_conv3, strides=[1, 1, 1, 1, 1], padding='SAME')

    w_height_conv1 = tf.get_variable(name='WGCN3DHeightConv1' + key, initializer=(tf.truncated_normal([1, FilterSize, 1, numofchannel, num_channel1], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    height_conv1 = tf.nn.conv3d(images, w_height_conv1, strides=[1, 1, 1, 1, 1], padding='SAME')
    w_height_conv2 = tf.get_variable(name='WGCN3DHeightConv2' + key, initializer=(tf.truncated_normal([FilterSize, 1, 1, num_channel1, num_channel1], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    height_conv2 = tf.nn.conv3d( height_conv1, w_height_conv2, strides=[1, 1, 1, 1, 1], padding='SAME')
    w_height_conv3 = tf.get_variable(name='WGCN3DHeightConv3' + key, initializer=(tf.truncated_normal([1, 1, FilterSize, num_channel1, num_channel1], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    height_conv3 = tf.nn.conv3d( height_conv2, w_height_conv3, strides=[1, 1, 1, 1, 1], padding='SAME')

    sum=depth_conv3+height_conv3

    w_width_conv1 = tf.get_variable(name='WGCN3DWidthConv1' + key, initializer=(tf.truncated_normal([1, 1, FilterSize, numofchannel, num_channel1], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    width_conv1 = tf.nn.conv3d(images, w_width_conv1, strides=[1, 1, 1, 1, 1], padding='SAME')
    w_width_conv2 = tf.get_variable(name='WGCN3DWidthConv2' + key, initializer=(tf.truncated_normal([1, FilterSize, 1, num_channel1, num_channel1], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    width_conv2 = tf.nn.conv3d( width_conv1, w_width_conv2, strides=[1, 1, 1, 1, 1], padding='SAME')
    w_width_conv3 = tf.get_variable(name='WGCN3DWidthConv3' + key, initializer=(tf.truncated_normal([FilterSize, 1, 1, num_channel1, num_channel1], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    width_conv3 = tf.nn.conv3d( width_conv2, w_width_conv3, strides=[1, 1, 1, 1, 1], padding='SAME')

    output = sum+width_conv3
    return output
#################################################

#################Global Convolutional Network##################################
def ConvGCN3D(images,FilterSize,OutNumChannel,key):
    b_Conv = tf.get_variable(name='BConvGCN3D' + key,initializer=(tf.truncated_normal(shape=[OutNumChannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    ConvMap = GCN3D(images,FilterSize,OutNumChannel,'ConvGCN3D' + key)
    Conv_cutoff = prelu(ConvMap + b_Conv, 'ConvGCN3DPrelu1' + key)
    return Conv_cutoff
###############################################################################



#################################################
def BoundaryRefinement(images,FilterSize,key):
    img_shape = images.get_shape()
    numofchannel = int(img_shape[4])
    b_br_conv1 = tf.get_variable(name='BBRConv1' + key,initializer=(tf.truncated_normal(shape=[numofchannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    w_br_conv1 = tf.get_variable(name='WBRConv1' + key, initializer=(tf.truncated_normal([FilterSize, FilterSize, FilterSize, numofchannel, numofchannel], mean=0.0, stddev=0.01375)), dtype=tf.float32)
    br_conv1 = tf.nn.conv3d(images, w_br_conv1, strides=[1, 1, 1, 1, 1], padding='SAME')
    left1_conv1_cutoff = prelu(br_conv1 +  b_br_conv1, 'BRPrelu1' + key)
    w_br_conv2 = tf.get_variable(name='WBRConv2' + key, initializer=(tf.truncated_normal([FilterSize, FilterSize, FilterSize, numofchannel, numofchannel], mean=0.0, stddev=0.01375)), dtype=tf.float32)
    br_conv2 = tf.nn.conv3d(left1_conv1_cutoff, w_br_conv2, strides=[1, 1, 1, 1, 1], padding='SAME')
    return  br_conv2+images
###############################################


##################3D Dilated Convolution#########################
def Atrous(images,FilterSize,OutNumChannel,DilationRate,key):
    img_shape = images.get_shape()
    Rate=FilterSize+(FilterSize-1)*(DilationRate-1)
    numofchannel = int(img_shape[4])
    w_AtrousConv = tf.get_variable(name='WAtrous' + key, initializer=(tf.truncated_normal([FilterSize, FilterSize, FilterSize, numofchannel, OutNumChannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    AtrousResult=tf.nn.convolution(images,w_AtrousConv,padding='SAME',dilation_rate=[Rate,Rate,Rate])
    return AtrousResult
#################################################################

##################3D Dilated Convolution#########################
def AtrousConv(images,FilterSize,OutNumChannel,DilationRate,key):
    img_shape = images.get_shape()
    numofchannel = int(img_shape[4])
    b_Atrous_conv1 = tf.get_variable(name='BAtrousConv1' + key,initializer=(tf.truncated_normal(shape=[OutNumChannel], mean=0.0, stddev=0.01375)),dtype=tf.float32)
    conv=Atrous(images,FilterSize,OutNumChannel,DilationRate,'AtrousConv1'+key)
    AtrousResult = prelu(conv +  b_Atrous_conv1, 'AtrousConv1Prelu' + key)
    return AtrousResult
#################################################################

#################AtrousSpatialPyramidPooling#####################
def ASPP(images,key):
    img_shape = images.get_shape()
    numofchannel = int(img_shape[4])
    conv1=Atrous(images, 3, 1, numofchannel/2, 'ASPP1'+key)
    conv2=Atrous(images, 3, 6, numofchannel/2, 'ASPP2'+key)
    conv3=Atrous(images, 3, 12, numofchannel/2, 'ASPP3'+key)
    conv4=Atrous(images, 3, 18, numofchannel/2, 'ASPP4'+key)
    AtrousSpatialPyramidPooling = tf.concat([conv1,conv2,conv3,conv4], 4)
    return AtrousSpatialPyramidPooling
#################################################################


def network(images,numoflabel,key,reuse=False):
    img_shape = images.get_shape()
    BatchSize = int(img_shape[0])
    depth = int(img_shape[1])
    height = int(img_shape[2])
    width = int(img_shape[3])
    numofchannel = int(img_shape[4])
    with tf.variable_scope("FCN",reuse=reuse) as scope:

        MAP = Conv(images, 5, 16, "1" + key)
        MAP2 = images+MAP


        MAP3 = PoolConv(MAP2, 2, 32, "4"+key)
        MAP4= Conv(MAP3, 5, 32, "5" + key)
        MAP5 = Conv(MAP4, 5, 32, "6"+key)
        MAP6 = MAP4+MAP5


        MAP7 = PoolConv(MAP6,2,64,"7"+key)
        MAP8 = Conv(MAP7, 5, 64, "8" + key)
        MAP9 =  Conv(MAP8, 5, 64, "9" + key)
        MAP10 = Conv(MAP9, 5, 64, "10"+key)
        MAP11 = MAP8+MAP10


        MAP7_2 = PoolConv(MAP11,2,128,"7_2"+key)
        MAP8_2 = Conv(MAP7_2, 5, 128, "8_2" + key)
        MAP9_2 =  Conv(MAP8_2, 5, 128, "9_2" + key)
        MAP10_2 = Conv(MAP9_2, 5, 128, "10_2"+key)
        MAP11_2 = MAP8_2+MAP10_2


        MAP12 = PoolConv(MAP11_2,2,256,"12"+key)
        MAP13 = Conv(MAP12, 5, 256, "13" + key)
        MAP13_2 = Conv(MAP13, 5, 256, "13_2" + key)
        MAP14 = Conv(MAP13_2, 5, 256, "14" + key)
        MAP15 = MAP12+MAP14
        #dropout = tf.nn.dropout(MAP15, 0.5)


        MAP16_1 = DeConv(MAP15, 2, 128, '16_1'+key)
        MAP17_1 = tf.concat([MAP11_2,MAP16_1],4)
        MAP17_1_2 = Conv(MAP17_1, 3, 128, '17_1_2' + key)
        MAP18_1 = GCN3D(MAP17_1_2, 9, 128, "18_1" + key)
        MAP19_1 = Conv(MAP18_1,3,128,"19_1" + key)
        MAP20_1 = MAP16_1+MAP19_1


        MAP16 = DeConv(MAP20_1, 2, 64, '16'+key)
        MAP17 = tf.concat([MAP11,MAP16],4)
        MAP17_2 = Conv(MAP17, 3, 64, '17_2' + key)
        MAP18 = GCN3D(MAP17_2, 11, 64, "18" + key)
        MAP19 = Conv(MAP18,3,64, "19" + key)
        MAP20 = MAP16+MAP19


        MAP21 = DeConv(MAP20, 2, 32, '21'+key)
        MAP22 = tf.concat([MAP6,MAP21],4)
        MAP22_2 = Conv(MAP22, 3, 32, '22_2' + key)
        MAP23 = GCN3D(MAP22_2, 13, 32, "23" + key)
        MAP24 = Conv(MAP23,3,32,"24"+key)
        MAP25 = MAP21+MAP24


        MAP26 = DeConv(MAP25, 2, 16, '26'+key)
        MAP27 = tf.concat([MAP2,MAP26],4)
        #MAP27_2 = Conv(MAP27, 3, 16, '27_2' + key)
        MAP28 = GCN3D(MAP27, 15, 16,"28" + key)
        MAP29 = Conv(MAP28,3,16,"29"+key)
        #dropout2 = tf.nn.dropout(MAP29, 0.5)
        MAP30 = ConvOnly(MAP29,1,numoflabel,"30"+key)
        output = MAP30

  
    return output



