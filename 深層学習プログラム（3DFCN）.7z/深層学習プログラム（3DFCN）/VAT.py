import tensorflow as tf
import model

def logit(x,numoflabel=3, key = '_1',reuse=True):
    return model.network(x, numoflabel,key,reuse=True)


def logsoftmax(x):
    xdev = x - tf.reduce_max(x, 1, keep_dims=True)
    lsm = xdev - tf.log(tf.reduce_sum(tf.exp(xdev), 1, keep_dims=True))
    return lsm


def kl_divergence_with_logit(q_logit, p_logit):
    q = tf.nn.softmax(q_logit)
    qlogq = tf.reduce_mean(tf.reduce_sum(q * logsoftmax(q_logit), 1))
    qlogp = tf.reduce_mean(tf.reduce_sum(q * logsoftmax(p_logit), 1))
    return qlogq - qlogp



################################正規化されたベクトルの生成############################
def get_normalized_vector(d):
    d /= (1e-12 + tf.reduce_max(tf.abs(d),axis = [1,2,3,4], keep_dims=True)) #range(1, len(d.get_shape()))
    d /= tf.sqrt(1e-6 + tf.reduce_sum(tf.pow(d, 2.0),axis = [1,2,3,4], keep_dims=True)) #range(1, len(d.get_shape()))
    return d

################################仮想的な摂動を生成####################################
def generate_virtual_adversarial_perturbation(x, logit, xi=1e-6, epsilon=2.0, weight=1.0, num_approximation=1, clip_value_min=1e-30, is_training=True):
    d = tf.random_normal(shape=tf.shape(x))

    for _ in range(num_approximation):
        d = xi * get_normalized_vector(d)
        logit_p = logit
        logit_m = logit(x + d)
        dist = kl_divergence_with_logit(logit_p, logit_m)                               #摂動と元画像の距離を計算するKLダイバージェンス
        grad = tf.gradients(dist, [d], aggregation_method=2)[0]                         #
        d = tf.stop_gradient(grad)

    return epsilon * get_normalized_vector(d)

########################仮想的な摂動のlossの計算#####################################
def virtual_adversarial_loss(x, logit, is_training=True, name="vat_loss"):
    r_vadv = generate_virtual_adversarial_perturbation(x, logit, is_training=is_training)
    logit = tf.stop_gradient(logit)
    logit_p = logit
    logit_m = logit(x + r_vadv)
    loss = kl_divergence_with_logit(logit_p, logit_m)                                   #摂動と元画像の距離を計算するKLダイバージェンス
    return tf.identity(loss, name=name)


def ce_loss(logit, y):
    print(tf.nn.softmax_cross_entropy_with_logits(logits=logit, labels=y))
    return tf.reduce_sum(tf.nn.softmax_cross_entropy_with_logits(logits=logit, labels=y)) #reduce_mean


def accuracy(logit, y):
    pred = tf.argmax(logit, 1)
    true = tf.argmax(y, 1)
    return tf.reduce_mean(tf.to_float(tf.equal(pred, true)))


def logsoftmax(x):
    xdev = x - tf.reduce_max(x, 1, keep_dims=True)
    lsm = xdev - tf.log(tf.reduce_sum(tf.exp(xdev), 1, keep_dims=True))
    return lsm


def kl_divergence_with_logit(q_logit, p_logit):
    q = tf.nn.softmax(q_logit)
    qlogq = tf.reduce_mean(tf.reduce_sum(q * logsoftmax(q_logit), 1))
    qlogp = tf.reduce_mean(tf.reduce_sum(q * logsoftmax(p_logit), 1))
    return qlogq - qlogp

def entropy_y_x(logit):
    p = tf.nn.softmax(logit)
    return -tf.reduce_mean(tf.reduce_sum(p * logsoftmax(logit), 1))

########################敵対的摂動を生成######################
def generate_adversarial_perturbation(x, loss, epsilon=2.0):
    grad = tf.gradients(loss, [x], aggregation_method=2)[0]
    grad = tf.stop_gradient(grad)
    return epsilon * get_normalized_vector(grad)

########################敵対的摂動のlossの計算########################
def adversarial_loss(x, y, loss, epsilon=2.0, is_training=True, name="at_loss"):
    r_adv = generate_adversarial_perturbation(x, loss,epsilon)
    logits = logit(x + r_adv)
    loss = ce_loss(logits, y)
    return [loss,x + r_adv]


"""
import tensorflow as tf

def logit(x, is_training=True, update_batch_stats=True, stochastic=True, seed=1234):
    return cnn.logit(x, is_training=is_training,
                     update_batch_stats=update_batch_stats,
                     stochastic=stochastic,
                     seed=seed)


def forward(x, is_training=True, update_batch_stats=True, seed=1234):
    if is_training:
        return logit(x, is_training=True,
                     update_batch_stats=update_batch_stats,
                     stochastic=True, seed=seed)
    else:
        return logit(x, is_training=False,
                     update_batch_stats=update_batch_stats,
                     stochastic=False, seed=seed)

def logsoftmax(x):
    xdev = x - tf.reduce_max(x, 1, keep_dims=True)
    lsm = xdev - tf.log(tf.reduce_sum(tf.exp(xdev), 1, keep_dims=True))
    return lsm


def kl_divergence_with_logit(q_logit, p_logit):
    q = tf.nn.softmax(q_logit)
    qlogq = tf.reduce_mean(tf.reduce_sum(q * logsoftmax(q_logit), 1))
    qlogp = tf.reduce_mean(tf.reduce_sum(q * logsoftmax(p_logit), 1))
    return qlogq - qlogp



################################正規化されたベクトルの生成############################
def get_normalized_vector(d):
    d /= (1e-12 + tf.reduce_max(tf.abs(d), range(1, len(d.get_shape())), keep_dims=True))
    d /= tf.sqrt(1e-6 + tf.reduce_sum(tf.pow(d, 2.0), range(1, len(d.get_shape())), keep_dims=True))
    return d

################################仮想的な摂動を生成####################################
def generate_virtual_adversarial_perturbation(x, logit, xi=1e-6, epsilon=2.0, weight=1.0, num_approximation=1, clip_value_min=1e-30, is_training=True):
    d = tf.random_normal(shape=tf.shape(x))

    for _ in range(num_approximation):
        d = xi * get_normalized_vector(d)
        logit_p = logit
        logit_m = forward(x + d, update_batch_stats=False, is_training=is_training)
        dist = kl_divergence_with_logit(logit_p, logit_m)                               #摂動と元画像の距離を計算するKLダイバージェンス
        grad = tf.gradients(dist, [d], aggregation_method=2)[0]                         #
        d = tf.stop_gradient(grad)

    return epsilon * get_normalized_vector(d)

########################仮想的な摂動のlossの計算#####################################
def virtual_adversarial_loss(x, logit, is_training=True, name="vat_loss"):
    r_vadv = generate_virtual_adversarial_perturbation(x, logit, is_training=is_training)
    logit = tf.stop_gradient(logit)
    logit_p = logit
    logit_m = forward(x + r_vadv, update_batch_stats=False, is_training=is_training)
    loss = kl_divergence_with_logit(logit_p, logit_m)                                   ##摂動と元画像の距離を計算するKLダイバージェンス
    return tf.identity(loss, name=name)

"""