###【１】初期設定###
import tensorflow as tf
import VAT
import model
import func
from datetime import datetime


##################各ファイル/フォルダの場所###############################
CsvPlace = r"./TestList.csv"
SaveModel=r"./NetworkModel/Model"
LoadModel=r"./NetworkModel/Model"
SaveData=r'./ClipData/ISSData'
SaveResult=r'./ResultData/ISSResult'
AccuracyLogPath=r'accuracy_log.txt'

loops = 1 #学習回数(評価の場合は、症例数)

BatchSize = 1
width_crop = 32
height_crop = 32
depth_crop = 32
numofchannel = 2
modelNum = str(30000) #学習済み特徴量のモデル名
alpha = 0.5 #損失関数に使用
tf.set_random_seed(0) #乱数固定(tensorflowでの学習結果を安定させる)

###【２】元データ/正解データの読込###

##プレースホルダーの作成##
#vif/volファイル名
FileNameX = tf.placeholder(tf.string, shape=(), name='FileNameX')
FileNameL = tf.placeholder(tf.string, shape=(), name='FileNameL')
FileNameF = tf.placeholder(tf.string, shape=(), name='FileNameF')
#Depth=Z,Height=Y,Width=X 画像サイズ
Depth = tf.placeholder(tf.int32, shape=(), name='DEPTH')
Height = tf.placeholder(tf.int32, shape=(), name='HEIGHT')
Width = tf.placeholder(tf.int32, shape=(), name='WIDTH')
#vifファイルのDataType(Signed Short等)
DataTypeData = tf.placeholder(tf.int32, shape=(), name='DATATYPEDATA')
DataTypeLabel = tf.placeholder(tf.int32, shape=(), name='DATATYPELABEL')
LearnImage = tf.placeholder(tf.int16, shape=None, name='LearnImage')
LearnLabel = tf.placeholder(tf.int16, shape=None, name='LearnLabel')
LearnImageCast = tf.cast(LearnImage, tf.float32)
LearnLabelCast = tf.cast(LearnLabel, tf.float32)
LearnImageReshape = tf.reshape(LearnImageCast, shape=(BatchSize, depth_crop, height_crop, width_crop, 1))
LearnLabelReshape = tf.reshape(LearnLabelCast, shape=(BatchSize, depth_crop, height_crop, width_crop, numofchannel))

##csvからvif/volデータ読み込み##
FileNameData, FileNameLabel = func.LoadCsv(CsvPlace)
FileNameDataVif = FileNameData + ".vif"
FileNameData = FileNameData + ".vol"
FileNameLabelVif = FileNameLabel + ".vif"
FileNameLabel = FileNameLabel + ".vol"
VifData = func.VifLoad(FileNameF)
images, labels = func.LoadDataSet(FileNameX, FileNameL, DataTypeData,DataTypeLabel, Depth, Height, Width)
CripImage, CripLabel = func.DataAugmentation(LearnImage, LearnLabel, Depth, Height, Width, depth_crop, height_crop, width_crop)

###【３】FCNの構築###
MAP = model.network(LearnImageReshape, numofchannel, '_1')

###【４】データ予測の準備###
imgdata = func.SaveImage(MAP) #予測結果の出力
accuracy = func.Accuracy(MAP, LearnLabelReshape) #予測結果の精度
aaa = tf.nn.softmax(MAP) #活性化関数

loss_function = func.crossentropy(MAP, LearnLabelReshape) #損失関数（学習誤差）

##過学習を防ぐ##
vat_loss,vatImage = VAT.adversarial_loss(LearnImageReshape, LearnLabelReshape, loss_function,epsilon=75000)
vat_reshape = tf.reshape(tf.cast(vatImage, tf.int16), shape=[depth_crop*height_crop*width_crop])
LOSS = alpha*loss_function + (1-alpha)*vat_loss

#train = tf.train.AdamOptimizer(1e-5).minimize(LOSS) #勾配降下法(学習時に使用)

##############################実行#############################
config = tf.ConfigProto()
config.gpu_options.allow_growth = True

with tf.Session(config=config) as sess:
    ### 【５】学習処理 ###
    sess.run(tf.global_variables_initializer()) #tensorflowの変数初期化
    saver_fcn = tf.train.Saver()
    saver_fcn.restore(sess, LoadModel+ "FCN" +modelNum+ ".ckpt") #学習済みモデルを使用する場合に記述
    coord = tf.train.Coordinator()
    threads = tf.train.start_queue_runners(sess=sess, coord=coord)

    print('START')
    time = datetime.now()
    print(time)
    summary_writer = tf.summary.FileWriter('./logs', graph=sess.graph)
    try:
        # 学習処理ループ
        for i in range(loops):
            string = str(i)#数値 i -> 文字列 string
            # 症例データ読込
            NameData, NameLabel, NameDataVif, NameLabelVif = sess.run([FileNameData,FileNameLabel, FileNameDataVif,FileNameLabelVif])
            DataVif = sess.run(VifData, feed_dict={FileNameF: NameDataVif})
            LabelVif = sess.run(VifData, feed_dict={FileNameF: NameLabelVif})
            depth, height, width, datatypelabel, VifFileSaveLabel = func.VifDecode(LabelVif, depth_crop, height_crop, width_crop,1)
            depth, height, width, datatypedata, VifFileSaveData = func.VifDecode(DataVif, depth_crop, height_crop, width_crop,3)
            Image, Label = sess.run([images, labels],
                                    feed_dict={FileNameX: NameData, FileNameL: NameLabel,
                                               Depth: depth, Height: height, Width: width,DataTypeData:datatypedata, DataTypeLabel:datatypelabel})
            # 画像のクロップ
            Image_crip, Label_crip = sess.run([CripImage , CripLabel],
                                    feed_dict={LearnImage: Image, LearnLabel: Label,
                                               Depth: depth, Height: height, Width: width})
            Image_crip, Label_crip = func.FlipData(Image_crip, Label_crip, depth_crop, height_crop, width_crop)
            # クロップした画像の分類結果（画素分け）
            Label_crip_Cre = func.CreatLabel(Label_crip,depth_crop,height_crop,width_crop,numofchannel)

            # 学習回数 50回 につき、以下を行う
            if i % 1 == 0:
                # 学習回数に応じたaccuracy, lossの算出
                VolFileSave,  train_accuracy, train_loss, aa,vatloss,vatimg = sess.run([imgdata, accuracy, loss_function, aaa,vat_loss,vat_reshape],###############
                                                                       feed_dict={LearnImage: Image_crip, LearnLabel: Label_crip_Cre})
                ac_log = open(AccuracyLogPath, mode='a', encoding='UTF-8')  # 評価値ログファイル出力

                # FCN予測データとラベルデータ間の精度
                Acu = func.EachAccuracy(VolFileSave, Label_crip, depth_crop, height_crop, width_crop, numofchannel)

                # 以下、画像書き出し
                fvol = open(
                    SaveResult + string + '.vol',
                    'wb')
                fvol.write(VolFileSave)
                fvol.close

                fvif = open(
                    SaveResult + string + '.vif',
                    'wb')
                fvif.write(VifFileSaveLabel)
                fvif.close

                fvol = open(
                    SaveResult + 'vat' + string + '.vol',
                    'wb')
                fvol.write(vatimg)
                fvol.close

                fvif = open(
                    SaveResult + 'vat' + string + '.vif',
                    'wb')
                fvif.write(VifFileSaveData)
                fvif.close

                fvol = open(
                    SaveData + string + '.vol',
                    'wb')
                fvol.write(Image_crip)
                fvol.close

                fvif = open(
                    SaveData + string + '.vif',
                    'wb')
                fvif.write(VifFileSaveData)
                fvif.close

                print("result")
                print("step %d,loss %g,VAT_loss %g, accuracy %g " % (i, train_loss, vatloss, train_accuracy))
                print(Acu)
                saver_fcn.save(sess,
                          SaveModel + "FCN" + string + ".ckpt")
                print("save")

                ac_log.write('--------------------')
                ac_log.write('Step:' + str(i) + '\r\n')
                ac_log.write('LabelAccuracy:' + str(Acu) + '\r\n')
                ac_log.write('train_loss:' + str(train_loss) + '\r\n')
                ac_log.close()

            time=datetime.now()
            print(time)
            print(i)
            #train.run(feed_dict={LearnImage: Image_crip, LearnLabel: Label_crip_Cre}, session=sess)

    except tf.errors.OutOfRangeError:
        print('Done training -- epoch limit reached')

    finally:

        coord.request_stop()
        coord.join(threads)

    sess.close()
    #################################################################
