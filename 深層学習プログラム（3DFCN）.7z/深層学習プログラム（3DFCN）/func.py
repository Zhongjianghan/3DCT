import tensorflow as tf
import random
import numpy as np

############CSV読み込み##############################
def LoadCsv(csvfile):

    # CSV ファイル名
    filename_queue = tf.train.string_input_producer([csvfile],name='CsvLoad')

    # TextLineReader 生成（1行ずつ読み込む Reader）
    reader_csv = tf.TextLineReader()
    key_csv, value_csv = reader_csv.read(filename_queue)

    # CSVデコード（列は3列、いずれもString）
    OriginalData, LabelData = tf.decode_csv(value_csv, [["aa"],["aa"]])

    return [OriginalData, LabelData]
##################################################################


############VIFデータ読み込み#####################################
def VifLoad(vif):

    read_vif = tf.read_file(vif)
    Vif = tf.reshape(read_vif, shape=[])

    return Vif
##################################################################

##########VIF Decode#############################################
def VifDecode(vif,crop_depth,crop_height,crop_width,datatype):
    vif=vif.decode('utf-8')
    VIF = str(vif)
    print(str(vif))
    VIF = VIF.split('\r\n')
    VIF1 = VIF[1].replace("  ", " ")
    VIF1 = VIF1.split(' ')
    VIF2 = VIF[2].replace("  ", " ")
    VIF21 = VIF2.split(' ')
    VIF3 = VIF[3].replace("  ", " ")
    VIF31 = VIF3.split(' ')
    VIF4 = VIF[4].replace("  ", " ")
    VIF41 = VIF4.split(' ')
    WIDTH = VIF21[1]
    HEIGHT = VIF21[2]
    DEPTH = VIF21[3]
    DATATYPE = VIF41[1]
    WIDTH = int(WIDTH)
    HEIGHT = int(HEIGHT)
    DEPTH = int(DEPTH)
    DATATYPE = int(DATATYPE)
    VIF21[1] =str(crop_width)
    VIF21[2] =str(crop_height)
    VIF21[3] =str(crop_depth)
    VIF41[1] =str(datatype)
    VIF21 = ' '.join(VIF21)
    VIF[2] = VIF21
    VIF41 = ' '.join(VIF41)
    VIF[4] = VIF41
    VIF = '\r\n'.join(VIF)
    Vif =VIF.encode('utf-8')
    return [DEPTH,HEIGHT,WIDTH,DATATYPE,Vif]
################################################################

############データ読み取り##############################
def LoadData(x,y,DataTypeData,DataTypeLabel,depth,height,width):
    read_image = tf.read_file(x)
    read_label = tf.read_file(y)

    record_bytes_image = tf.cond(tf.equal(DataTypeData,1),  lambda:tf.cast(tf.decode_raw(read_image, tf.int8),tf.int32),
                                 lambda:tf.cond(tf.equal(DataTypeData,2),  lambda:tf.cast(tf.decode_raw(read_image, tf.int16),tf.int32),
                                         lambda:tf.cond(tf.equal(DataTypeData,3),  lambda:tf.cast(tf.decode_raw(read_image, tf.int16),tf.int32),
                                                           lambda:tf.cond(tf.equal(DataTypeData,4), lambda:tf.decode_raw(read_image,tf.int32), lambda:tf.decode_raw(read_image,tf.int32)))))

    record_bytes_label = tf.cond(tf.equal(DataTypeLabel,1),  lambda:tf.cast(tf.decode_raw(read_label, tf.int8),tf.int32),
                                 lambda:tf.cond(tf.equal(DataTypeLabel,2),  lambda:tf.cast(tf.decode_raw(read_label, tf.int16),tf.int32),
                                         lambda:tf.cond(tf.equal(DataTypeLabel,3),  lambda:tf.cast(tf.decode_raw(read_label, tf.int16),tf.int32),
                                                           lambda:tf.cond(tf.equal(DataTypeLabel,4), lambda:tf.decode_raw(read_label,tf.int32), lambda:tf.decode_raw(read_label,tf.int32)))))

    return[record_bytes_image ,record_bytes_label]
###########################################################


###############################################################################
def DataAugmentation(image, labels,depth,height,width, crop_depth,crop_height,crop_width):
    RANDOMSEED = random.randint(0, 10000000)
    reshaped_image = tf.reshape(image, [depth , height , width, 1])
    reshaped_labels = tf.reshape(labels, [depth , height , width, 1])

    distorted_image = tf.random_crop(reshaped_image, [crop_depth, crop_height, crop_width,1],seed=RANDOMSEED)
    distorted_labels = tf.random_crop(reshaped_labels, [crop_depth, crop_height, crop_width,1], seed=RANDOMSEED)

    distorted_image = tf.reshape(distorted_image, [crop_depth*crop_height*crop_width])
    distorted_labels = tf.reshape(distorted_labels, [crop_depth*crop_height*crop_width])

    #distorted_image = tf.image.random_brightness(distorted_image, max_delta=63 ,seed=randam_seed)
    #float_image = tf.image.random_contrast(distorted_image, lower=0.2, upper=1.8 ,seed=randam_seed)
    return [distorted_image,distorted_labels]
###############################################################################

##########################################################################
def FlipData(Image,Label,Depth,Height,Width,channel=1):
    flagx = random.randint(1, 100) % 2
    flagy = random.randint(1, 100) % 2
    flagz = random.randint(1, 100) % 2

    ImageData = np.array(Image)
    LabelData = np.array(Label)
    newImage = np.array(Image)
    newLabel = np.array(Label)

    ImageData = ImageData.reshape((Depth,Height,Width,1))
    LabelData = LabelData.reshape((Depth,Height,Width,channel))
    newImage = newImage.reshape((Depth,Height,Width,1))
    newLabel = newLabel.reshape((Depth,Height,Width,channel))

    if flagx == 1:
        for i in range(0, Depth):
            for j in range(0, Height):
                for k in range(0, Width):
                    indexx = int(k)
                    indexy = int(j)
                    indexz = int(i)
                    newImage[indexz, indexy, indexx,0] = ImageData[indexz, indexy, Width - 1 - indexx,0]
                    for l in range(0, channel):
                        indexc = int(l)
                        newLabel[indexz, indexy, indexx,indexc] = LabelData[indexz,indexy,Width -1 - indexx,indexc]

        for i in range(0, Depth):
            for j in range(0, Height):
                for k in range(0, Width):
                    indexx = int(k)
                    indexy = int(j)
                    indexz = int(i)
                    ImageData[indexz, indexy, indexx,0] = newImage[indexz, indexy, indexx,0]
                    for l in range(0, channel):
                        indexc = int(l)
                        LabelData[indexz, indexy, indexx,indexc] = newLabel[indexz, indexy, indexx,indexc]


    if flagy == 1:
        for i in range(0, Depth):
            for j in range(0, Height):
                for k in range(0, Width):
                    indexx = int(k)
                    indexy = int(j)
                    indexz = int(i)
                    newImage[indexz, indexy, indexx,0] = ImageData[indexz, Height -1 - indexy,indexx,0]
                    for l in range(0, channel):
                        indexc = int(l)
                        newLabel[indexz, indexy, indexx,indexc] = LabelData[indexz, Height -1 - indexy,indexx,indexc]

        for i in range(0, Depth):
            for j in range(0, Height):
                for k in range(0, Width):
                    indexx = int(k)
                    indexy = int(j)
                    indexz = int(i)
                    ImageData[indexz, indexy, indexx,0] = newImage[indexz, indexy, indexx,0]
                    for l in range(0, channel):
                        indexc = int(l)
                        LabelData[indexz, indexy, indexx,indexc] = newLabel[indexz, indexy, indexx,indexc]


    if flagz == 1:
        for i in range(0, Depth):
            for j in range(0, Height):
                for k in range(0, Width):
                    indexx = int(k)
                    indexy = int(j)
                    indexz = int(i)
                    newImage[indexz, indexy, indexx,0] = ImageData[Depth -1 - indexz,indexy,indexx,0]
                    for l in range(0, channel):
                        indexc = int(l)
                        newLabel[indexz, indexy, indexx ,indexc] = LabelData[Depth -1 - indexz,indexy,indexx,indexc]

        for i in range(0, Depth):
            for j in range(0, Height):
                for k in range(0, Width):
                    indexx = int(k)
                    indexy = int(j)
                    indexz = int(i)
                    ImageData[indexz, indexy, indexx,0] = newImage[indexz, indexy, indexx,0]
                    for l in range(0, channel):
                        indexc = int(l)
                        LabelData[indexz, indexy, indexx, indexc] = newLabel[indexz, indexy, indexx, indexc]



    newImage = np.reshape(newImage,[Depth * Height * Width])
    newLabel = np.reshape(newLabel,[Depth * Height * Width * channel])
    return [newImage,newLabel]
##########################################################################


###############################################################################
def LoadDataSet(x,y,DataTypeData,DataTypeLabel,depth,height,width):
    image_size = width * height * depth
    Image,Label=LoadData(x, y,DataTypeData,DataTypeLabel, depth, height, width)
    image_reshape = tf.reshape(tf.slice(Image, [0], [image_size]), [depth * height * width])
    label_reshape = tf.reshape(tf.slice(Label, [0], [image_size]), [depth * height * width])
    return [image_reshape,label_reshape]
###############################################################################


############diceに基づく損失関数の定義##################
def dice(pred, label):
    pred = tf.nn.softmax(pred)
    dice_numerator = 2.0 * tf.reduce_sum(label * pred,axis=[1,2,3])
    dice_denominator = (tf.reduce_sum(tf.square(pred),axis=[1,2,3]) + tf.reduce_sum(tf.square(label),axis=[1,2,3]))
    epsilon = 0.1
    dice_score = (dice_numerator + epsilon) / (dice_denominator + epsilon)
    dice_score2=tf.reduce_mean(dice_score,axis=[1])
    return 1.0 - tf.reduce_mean(dice_score2)
###########################################################

############cross_entropy損失関数の定義##################
def crossentropy(pred, label):
    cross_entropy=tf.nn.softmax_cross_entropy_with_logits(labels=label,logits=pred)
    cross_entropy=tf.reduce_sum(cross_entropy)
    return cross_entropy
###########################################################


###########################予測結果の出力#################################
def SaveImage(MAP):
    img_shape = MAP.get_shape()
    BatchSize = int(img_shape[0])
    depth = int(img_shape[1])
    height = int(img_shape[2])
    width = int(img_shape[3])
    numofchanel = int(img_shape[4])
    soft = tf.nn.softmax(MAP)
    result = tf.argmax(soft, axis=4)
    result_cast = tf.cast(result, dtype=tf.int8)
    result_reshape = tf.reshape(result_cast, shape=[depth * height * width])
    return result_reshape
##########################################################################

##########################予測精度の計算##################################
def Accuracy(MAP,LABELS):
    soft = tf.nn.softmax(MAP)
    result = tf.argmax(soft, axis=4)
    correct_prediction = tf.equal(result, tf.argmax(LABELS, axis=4))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, dtype=tf.float32))
    return accuracy
##########################################################################

##########################################################################
def EachAccuracy(MAP,Label,Depth,Height,Width,NumOfLabel):
    PredData = np.array(MAP)
    LabelData = np.array(Label)

    LabelTotal1 = np.zeros([NumOfLabel], dtype=np.float32)
    LabelTotal2 = np.zeros([NumOfLabel], dtype=np.float32)
    LabelAcu = np.zeros([NumOfLabel], dtype=np.float32)
    NumOfData = Depth*Height*Width

    for i in range(0,NumOfData):
        index1 = int(i)
        index2 = int(LabelData[index1])
        LabelTotal1[index2] = int(LabelTotal1[index2]) + 1
        if LabelData[index1] == PredData[index1]:
            LabelTotal2[index2] = int(LabelTotal2[index2]) + 1

    for i in range(0, NumOfLabel):
        index1 = int(i)
        LabelAcu[index1] = LabelTotal2[index1] / LabelTotal1[index1]

    print(LabelTotal1)
    print(LabelTotal2)

    return LabelAcu
##########################################################################

##########################################################################
def NumpySliceLoad(Image,offset_depth,offset_height,offset_width,target_depth,target_height,target_width):
    numImage=np.array(Image)
    array1 = numImage[offset_depth:target_depth, offset_height:target_height, offset_width:target_width].copy()
    array1 = array1.tolist()
    return array1
##########################################################################

##########################################################################
def NumpySliceSave(Image,array1,offset_depth,offset_height,offset_width,target_depth,target_height,target_width):
    numImage = np.array(Image)
    numarray1 = np.array(array1)
    numImage[offset_depth:target_depth, offset_height:target_height, offset_width:target_width]=numarray1
    numImage = numImage.tolist()
    return numImage
##########################################################################

##########################################################################
def CreatLabel(Label,Depth,Height,Width,NumOfLabel):
    LabelData = np.array(Label)
    LabelFull0 = np.zeros([Depth*Height*Width,NumOfLabel], dtype=np.int8)
    NumOfData = Depth*Height*Width

    for i in range(0,NumOfData):
        index1 = int(i)
        index2 = int(LabelData[index1])
        LabelFull0[index1,index2] = 1

    numLabel = LabelFull0.tolist()
    return numLabel
##########################################################################

def resize(x,depth,height,width):
    return tf.keras.backend.resize_volumes(
        x,
        depth,
        height,
        width,
        "channels_last"
    )
